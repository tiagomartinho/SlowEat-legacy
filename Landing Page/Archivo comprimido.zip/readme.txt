Deploy

Zip the folder contents into a zip, not the folder

Upload the zip into:
https://cp.tophost.it/wftp/index.php

